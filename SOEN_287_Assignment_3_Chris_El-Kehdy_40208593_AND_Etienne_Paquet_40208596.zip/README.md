Website URL: https://trocery.com

Test logins (email:password)
Admin user: Admin:Admin
Customer user 1: test@example.com:12345
Customer user 2: test2@example.com:12345